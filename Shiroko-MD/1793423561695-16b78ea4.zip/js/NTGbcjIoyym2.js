(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))r(t);new MutationObserver(t=>{for(const s of t)if(s.type==="childList")for(const p of s.addedNodes)p.tagName==="LINK"&&p.rel==="modulepreload"&&r(p)}).observe(document,{childList:!0,subtree:!0});function i(t){const s={};return t.integrity&&(s.integrity=t.integrity),t.referrerPolicy&&(s.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?s.credentials="include":t.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function r(t){if(t.ep)return;t.ep=!0;const s=i(t);fetch(t.href,s)}})();function f(){const e=document.querySelector("#menu-toggle"),a=document.querySelector("#drawer"),i=document.querySelector("#drawer-backdrop"),r=t=>{e.classList.toggle("menu-open",t),a.classList.toggle("is-open",t),i.classList.toggle("is-open",t),e.setAttribute("aria-expanded",String(t)),e.setAttribute("aria-label",t?"Tutup menu":"Buka menu")};e.addEventListener("click",()=>r(!a.classList.contains("is-open"))),i.addEventListener("click",()=>r(!1)),a.querySelectorAll("a").forEach(t=>t.addEventListener("click",()=>r(!1))),document.addEventListener("keydown",t=>{t.key==="Escape"&&r(!1)})}const c=["https://u.pone.rs/fgatyngd.png","https://u.pone.rs/lvkgfwnb.png","https://u.pone.rs/heqdxtjf.png","https://u.pone.rs/egxqinhc.jpg","https://u.pone.rs/vyrquvxq.jpg","https://u.pone.rs/giqqqeiv.jpg","https://u.pone.rs/nkdssjjf.jpg","https://u.pone.rs/ucgejmvv.jpg","https://u.pone.rs/xpkfbzbl.jpg","https://u.pone.rs/dxtuykwu.jpg","https://u.pone.rs/jsufabxc.jpg","https://u.pone.rs/facacpaw.jpg","https://u.pone.rs/xocneaht.jpg","https://u.pone.rs/nldbugms.jpg","https://u.pone.rs/vndwiigl.jpg","https://u.pone.rs/gtlvtzfw.jpg","https://u.pone.rs/ulzxnxvu.jpg"];function o(){return c[Math.floor(Math.random()*c.length)]}const n={name:"Dhanyy",role:"Programmer pemula",age:16,birthday:"10 September 2010",phone:"083857053843",photo:"https://u.pone.rs/rrmadxix.jpg",thumbnail:"https://u.pone.rs/rnolhgue.mp4",about:"Halo, saya Rizkyansyah Syawardhany, biasa dipanggil Rizky/Dhanyy. Saya adalah programmer new: membuat website HTML sederhana dan me-rename script bot.",journeyStart:"3 September 2026"},A=[{name:"HTML",stars:4},{name:"CSS",stars:2},{name:"JavaScript",stars:4},{name:"Python",stars:2},{name:"Node.js ESM",stars:4}],L=["ELLA-MD","Zavier MD"],v=[{label:"TikTok",url:"https://www.tiktok.com/@prince_dhanyy"},{label:"Instagram",url:"https://www.instagram.com/xdhany48"},{label:"Saluran WhatsApp",url:"https://whatsapp.com/channel/0029Vb8VtwW3wtbAWrhIo01Z"}],S=[{name:"Dana",type:"number",value:"083857053843"},{name:"Gopay",type:"number",value:"083857053843"},{name:"Qris",type:"image",value:"https://u.pone.rs/wtqsyrfm.jpg"}],D=2400,x=500;function M(e){const a=document.querySelector("#loader");a.querySelector("img").src=o(),setTimeout(()=>{a.classList.add("is-hidden"),setTimeout(()=>{a.remove(),e()},x)},D)}function P(e){e.innerHTML=`
    <section class="card hero">
      <div class="hero-text">
        <p class="eyebrow">Dashboard</p>
        <h1>Halo, saya ${n.name}</h1>
        <p>${n.role}. Selamat datang di website portofolio saya.</p>
        <p class="hint">Pilih halaman di bawah, atau buka menu garis tiga di pojok kiri atas.</p>
      </div>
      <img class="sticker" src="${o()}" alt="" />
    </section>
    <nav class="tiles" aria-label="Halaman">
      <a class="tile" href="#/portfolio">
        <span class="tile-num">01</span>
        <h2>Portofolio</h2>
        <p class="tile-desc">Profil, keahlian, project, dan media sosial.</p>
      </a>
      <a class="tile" href="#/script">
        <span class="tile-num">02</span>
        <h2>Info Script</h2>
        <p class="tile-desc">Penjelasan script ELLA-MD dan fitur-fiturnya.</p>
      </a>
      <a class="tile" href="#/donasi">
        <span class="tile-num">03</span>
        <h2>Donasi</h2>
        <p class="tile-desc">Dukung pengembangan dengan Dana, Gopay, atau QRIS.</p>
      </a>
    </nav>
  `}const w=e=>"★".repeat(e)+"☆".repeat(5-e);function E(e){e.innerHTML=`
    <section class="card hero">
      <img class="avatar" src="${n.photo}" alt="Foto profil ${n.name}" />
      <div class="hero-text">
        <p class="eyebrow">Portofolio</p>
        <h1>${n.name}</h1>
        <p>${n.role}</p>
        <dl class="facts">
          <dt>Nama</dt><dd>${n.name}</dd>
          <dt>Umur</dt><dd>${n.age} tahun</dd>
          <dt>Ulang tahun</dt><dd>${n.birthday}</dd>
          <dt>Nomor</dt><dd>${n.phone}</dd>
        </dl>
      </div>
      <img class="sticker" src="${o()}" alt="" />
    </section>

    <div class="grid-2">
      <section class="card span-2">
        <h2>Thumbnail</h2>
        <div class="video-frame">
          <video src="${n.thumbnail}" autoplay muted loop playsinline></video>
        </div>
      </section>

      <section class="card span-2">
        <h2>Tentang Saya</h2>
        <p>${n.about}</p>
      </section>

      <section class="card">
        <h2>Keahlian</h2>
        ${A.map(a=>`
          <div class="skill-row">
            <span>${a.name}</span>
            <span class="stars" aria-label="${a.stars} dari 5">${w(a.stars)}</span>
          </div>`).join("")}
      </section>

      <section class="card">
        <h2>Project</h2>
        <div class="chip-row">
          ${L.map(a=>`<span class="pill">${a}</span>`).join("")}
        </div>
        <h2>Perjalanan</h2>
        <p>Dimulai dari ${n.journeyStart}.</p>
      </section>

      <section class="card span-2">
        <h2>Media Sosial</h2>
        <div class="link-row">
          ${v.map(a=>`<a class="btn btn-ghost" href="${a.url}" target="_blank" rel="noopener noreferrer">${a.label}</a>`).join("")}
        </div>
      </section>
    </div>
  `}const j=[{title:"ELLA-MD — WhatsApp Automation System",blocks:[{type:"h",text:"Introducing ELLA-MD"},{type:"p",text:"ELLA-MD merupakan script bot WhatsApp multifungsi yang dikembangkan untuk menghadirkan pengalaman otomatisasi komunikasi yang praktis, modern, dan fleksibel."},{type:"p",text:"Dibangun menggunakan JavaScript dengan sistem ECMAScript Modules (ESM) dan runtime Node.js, ELLA-MD mengadopsi arsitektur plugin modular yang memungkinkan setiap fitur dikelola dan dikembangkan secara terpisah."},{type:"p",text:"Dengan beragam kategori fitur, mulai dari kecerdasan buatan (AI), pengelolaan grup, downloader, permainan, hingga berbagai utilitas, ELLA-MD dirancang untuk memenuhi kebutuhan otomatisasi WhatsApp dalam satu sistem terintegrasi."},{type:"h",text:"Keunggulan Utama:"},{type:"ul",items:["Modular Plugin Architecture","Flexible Feature Management","Modern JavaScript Technology","Automated WhatsApp Interaction","Extensible System Architecture"]},{type:"p",text:"ELLA-MD hadir sebagai fondasi pengembangan bot WhatsApp yang mengutamakan fleksibilitas, fungsionalitas, dan kemudahan pengembangan."},{type:"tagline",text:"ELLA-MD — One System, Multiple Possibilities."}]},{title:"ELLA-MD — Features & Categories",blocks:[{type:"p",text:"ELLA-MD menghadirkan berbagai modul plugin dengan kategori yang dirancang untuk mendukung kebutuhan otomatisasi, produktivitas, hiburan, dan pengelolaan bot WhatsApp."},{type:"h",text:"Statistik Script"},{type:"ul",items:["361 Plugin Files","24 Feature Categories","Modular Plugin System","JavaScript ESM"]},{type:"h",text:"Daftar Kategori Fitur"},{type:"ol",items:["AI — Kecerdasan buatan dan asisten AI.","Anime — Pencarian anime dan manga.","Audio — Pemrosesan dan manipulasi audio.","Downloader — Pengunduhan media dari berbagai layanan.","Fun — Hiburan dan fitur interaktif.","Game — Permainan berbasis WhatsApp.","Group — Administrasi dan pengelolaan grup.","Image — Pengolahan dan manipulasi gambar.","Info — Informasi dan data.","Internet — Utilitas layanan internet.","JPM — Pengelolaan pengiriman pesan massal.","Main — Perintah utama dan fungsi dasar bot.","Maker — Pembuatan konten dan media.","NSFW — Kategori konten khusus dewasa.","Owner — Pengaturan dan perintah khusus pemilik.","RPG — Permainan dengan sistem progres.","Search — Pencarian informasi dan konten.","Stalk — Pencarian informasi akun melalui layanan terkait.","Sticker — Pembuatan dan pengolahan stiker.","Store — Fitur toko dan transaksi.","System — Pengelolaan sistem bot.","Tools — Berbagai alat bantu dan utilitas.","UI — Komponen antarmuka dan interaksi.","JKT48 — Informasi dan fitur seputar JKT48."]},{type:"h",text:"Sistem Pengelolaan Fitur"},{type:"p",text:"Setiap plugin memiliki fungsi tersendiri dan dikelola melalui sistem modular. Arsitektur ini mempermudah pemeliharaan, pengembangan, serta penambahan fungsionalitas baru."},{type:"tagline",text:"ELLA-MD — 361 Plugin Files. 24 Categories. One Integrated System."}]},{title:"ELLA-MD — Developer Information",blocks:[{type:"h",text:"Developer Profile"},{type:"h",text:"DHANYY-INFINITY"},{type:"p",text:"DHANYY-INFINITY merupakan pengembang di balik proyek ELLA-MD, sebuah sistem bot WhatsApp yang berfokus pada otomatisasi komunikasi, pengembangan fitur, dan fleksibilitas arsitektur perangkat lunak."},{type:"p",text:"ELLA-MD dikembangkan dengan pendekatan modular untuk mempermudah pengelolaan sistem, pemeliharaan kode, serta pengembangan fungsionalitas secara berkelanjutan."},{type:"h",text:"Project Information"},{type:"ul",items:["Project Name: ELLA-MD","Owner & Developer: DHANYY-INFINITY","Platform: WhatsApp","Programming Language: JavaScript","Module System: ECMAScript Modules (ESM)","Runtime Environment: Node.js","WhatsApp Library: Baileys","Database: JSON","Architecture: Modular Plugin System","Media Processing: FFmpeg"]},{type:"h",text:"Development Focus"},{type:"ul",items:["Pengembangan sistem bot WhatsApp.","Implementasi arsitektur plugin modular.","Integrasi API dan layanan eksternal.","Pengelolaan database dan pencadangan data.","Pemantauan sistem dan penanganan kesalahan.","Peningkatan fungsionalitas serta pemeliharaan kode."]},{type:"h",text:"Acknowledgements & Special Thanks"},{type:"p",text:"Pengembangan ELLA-MD tidak terlepas dari dukungan, kontribusi, inspirasi, dan bantuan berbagai pihak."},{type:"h",text:"Developer & Partners"},{type:"ul",items:["DHANYY-INFINITY — Owner & Developer","Cristy — Riki (Partner)","Lian Ai — Lian (Partner)","All Developers Bot — Seluruh developer bot yang dikenal."]},{type:"h",text:"AI Assistants & Technical Support"},{type:"ul",items:["GPT (OpenAI)","DeepSeek","Assistant Who Helps Fix — Asisten yang membantu proses perbaikan dan penyelesaian kendala teknis."]},{type:"h",text:"Technology & Contributors"},{type:"ul",items:["Baileys — WhatsApp Library","Node.js — Runtime Environment","Ryo Yamada — Hilman","Anya — Hamm","Astra — Vinz","AstroJmk — Aris","api.kyzzz.xyz — Web API","kyuuu"]},{type:"h",text:"Additional Appreciation"},{type:"p",text:"Terima kasih kepada seluruh kontributor, supporter, pengguna, serta pihak lain yang telah memberikan dukungan dan inspirasi selama proses pengembangan ELLA-MD."},{type:"h",text:"Vision & Commitment"},{type:"p",text:"ELLA-MD dikembangkan dengan komitmen untuk menghadirkan sistem bot WhatsApp yang fleksibel, terstruktur, dan dapat diperluas sesuai kebutuhan."},{type:"p",text:"Melalui eksplorasi teknologi, kolaborasi, serta pengembangan berkelanjutan, ELLA-MD diharapkan dapat terus berkembang menjadi proyek yang lebih baik."},{type:"tagline",text:"Built with Creativity. Improved Through Collaboration."},{type:"p",text:"ELLA-MD — Developed by DHANYY-INFINITY."},{type:"note",text:"© DHANYY-INFINITY. All Rights Reserved."}]}],l=e=>e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");function I(e){const a=l(e.text??"");switch(e.type){case"h":return`<h3>${a}</h3>`;case"p":return`<p>${a}</p>`;case"note":return`<p class="note">${a}</p>`;case"tagline":return`<p class="tagline">${a}</p>`;case"ul":return`<ul>${e.items.map(i=>`<li>${l(i)}</li>`).join("")}</ul>`;case"ol":return`<ol>${e.items.map(i=>`<li>${l(i)}</li>`).join("")}</ol>`}}function $(e){e.innerHTML=`
    <section class="card hero">
      <div class="hero-text">
        <p class="eyebrow">Info Script</p>
        <h1>ELLA-MD</h1>
        <p>WhatsApp Automation System berbasis JavaScript, ESM, dan Node.js.</p>
      </div>
      <img class="sticker" src="${o()}" alt="" />
    </section>
    ${j.map(a=>`
      <section class="card script-section">
        <h2>${l(a.title)}</h2>
        ${a.blocks.map(I).join("")}
      </section>`).join("")}
  `}const T=1600;function N(e){const a=e.type==="image"?`<div class="qr-frame"><img src="${e.value}" alt="Kode QRIS ${e.name}" /></div>`:`<p class="donate-number">${e.value}</p>
         <button type="button" class="btn copy-btn" data-copy="${e.value}">Salin nomor</button>`;return`
    <section class="card donate-card">
      <p class="eyebrow">${e.name}</p>
      ${a}
    </section>`}async function F(e){const a=e.textContent;try{await navigator.clipboard.writeText(e.dataset.copy),e.textContent="Tersalin!",e.classList.add("is-copied")}catch{e.textContent="Gagal menyalin"}setTimeout(()=>{e.textContent=a,e.classList.remove("is-copied")},T)}function H(e){e.innerHTML=`
    <section class="card hero">
      <div class="hero-text">
        <p class="eyebrow">Donasi</p>
        <h1>Dukung ELLA-MD</h1>
        <p>Terima kasih atas dukunganmu. Pilih metode donasi yang kamu inginkan.</p>
      </div>
      <img class="sticker" src="${o()}" alt="" />
    </section>
    <div class="grid-3">
      ${S.map(N).join("")}
    </div>
  `,e.querySelectorAll("[data-copy]").forEach(a=>{a.addEventListener("click",()=>F(a))})}const b={dashboard:P,portfolio:E,script:$,donasi:H},W="dashboard",C=380,m=document.querySelector("#page"),u=document.querySelector("#wipe");let d=null,g=null;function h(){const e=window.location.hash.replace(/^#\//,"");return Object.hasOwn(b,e)?e:W}function Y(e){document.querySelectorAll("[data-route]").forEach(a=>{a.classList.toggle("is-active",a.dataset.route===e)})}function y(e){m.replaceChildren(),b[e](m),Y(e),window.scrollTo({top:0}),d=e}function k(){const e=h();if(e!==d){if(d===null){y(e);return}u.classList.remove("is-running"),u.offsetWidth,u.classList.add("is-running"),clearTimeout(g),g=setTimeout(()=>y(h()),C)}}f();window.addEventListener("hashchange",k);M(k);
